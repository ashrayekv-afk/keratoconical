# Verification report — 9.1.2-map-coverage

This release adds an independent detailed quantitative map layer and bounded, identifiable small-gap display estimates. Tests verify data preservation and implementation behavior. They do not establish clinical accuracy or an exact patient replica.

## Scope and retained behavior

The prior 41 × 41 regional grids, 61 × 61 reconstruction grids, reconstructed coordinates, source point measurements, thinnest-point selection and trained calculator models are retained. Changes are confined to extra display sampling, metadata, quantitative rendering, explanatory labels, version identifiers and documentation. Native missing measurements are not filled. Unsupported source geometry stays open.

Python calculation files and trained artifacts remain byte-identical except the interface version/component identifiers. Dependency declarations and OCR runtime/worker/language assets are unchanged. The release builder enforces the previous source manifest and an explicit edit/addition allowlist.

## Completed source and browser checks

| Check | Result |
| --- | --- |
| New coverage helper | 13 checks passed, including physical bounds, clipped/boundary/geometry exclusions, direct-only donors, no recursive fills, native missing data, signed fields, source/minimum immutability and exact constant native values. |
| Detailed image sampling | 3 new checks passed; legacy full-report display and integrated-reader suites passed. |
| Existing model and measurement helpers | 12 model and 12 measurement checks passed. |
| Independent source-model comparison | 22 cases passed. Original vertices, triangles, values and minima match v9.1.1, including fresh reports, native maps, reflected axes, sparse data and invalid-source rejection. |
| WebGL browser acceptance | 19 groups passed. |
| Canvas fallback acceptance | 19 groups passed. |
| Gap holdout/exclusion checks | 8 engineering groups passed, with 321 held-out spatial blocks in the evidence set. |

Browser checks cover all five quantitative fields, natural view, paired eyes, missing values, signed scales, shared bounds, visit selection, manual/thinnest-point selection, whole/section views, estimate toggles, PNG export, source footprints beside missing samples, native holes, constant maps and 320-pixel layouts. Original source values stay unavailable where appropriate even if a separate display estimate exists. Browser runs had no uncaught page errors or external requests.

An identified native constant-field rounding issue was corrected: regular grids copy values exactly after orientation conversion, and display range preparation does not amplify machine-precision differences. Display percentages show `<0.1%` for a nonzero fraction below one tenth of a percent.

## Production report-reader verification

Four previously supplied original report pages were processed through the production reader and bundled OCR workers. The run made 62 OCR calls, with no manual metadata substitutions, no page errors, no failed requests and no external requests. It generated all ten expected detailed fields across the two test eyes.

After removing only the new optional `display_detail` property, the resulting report-page objects were exactly equal to the previously verified production extraction. This includes all central/full grids, accepted legend calibration, map identity and reference metadata. New detailed fields contain 121 × 121 positions over the same printed map circle. More samples do not increase the original report's color precision.

These older test reports are not assumed to be the examination pictured in the user's latest photograph. Actual report images, extracted patient grids, photographs and QA screenshots are not included in this release archive.

## Interpolation holdouts

The independent validation temporarily removed spatial patches from analytic fields and supported source colors, then attempted reconstruction without those values. It tested different component sizes and refused ineligible gaps. The source-color subset below contains single-sample holdouts at distributed supported positions. Multi-sample blocks were additionally tested on analytic fields; this does not establish performance for every real multi-sample obstruction.

| Held-out report-color field | Filled / tested | Mean absolute difference | Maximum absolute difference |
| --- | ---: | ---: | ---: |
| Pachymetry | 28 / 36 | 2.84 µm | 11.00 µm |
| Anterior curvature | 29 / 36 | 0.292 D | 1.485 D |
| Posterior curvature magnitude | 24 / 31 | 0.044 D | 0.117 D |
| Anterior elevation | 21 / 36 | 1.53 µm | 3.65 µm |
| Posterior elevation | 6 / 22 | 2.00 µm | 4.08 µm |

These differences measure reproduction of held-out image-derived color estimates. They are not errors against independently measured native corneal coordinates, not a clinical acceptance threshold, and not confidence intervals for the missing areas. Refused holdouts remain unavailable and are excluded from the error summaries. An unobserved minimum or peak inside a gap can remain undiscoverable from surrounding samples.

The policy caps physical span at 0.30 mm and area at 0.075 mm²; requires at least eight original direct-color donors in four quadrants within 0.45 mm; checks local-fit consistency against source color-interval width; and bounds results by donor values. These engineering choices remain explicit in the source. The estimator does not use existing recovered colors or previous fills as donors.

## Packaged application gate

The clean extracted-package gate passed: exactly five upload files; 130 runtime members with 129 source manifest entries; matching launcher/runtime checksum; safe ZIP membership and CRCs; and 41 valid local HTML asset references. The launcher started from a different working directory in a clean temporary cache. Baseline and longitudinal OD/OS score/PDF events passed. Four complete representative calculator outputs were exactly equal to v9.1.1 after excluding the UI version.

Nine actual packaged Streamlit browser groups passed. They verified the served helper/stylesheet identity, automatic original-map association, the original reconstructed minimum, all five quantitative modes, the estimate toggle, unchanged source readings, responsive layouts at 1280/390/320 pixels, PNG export, and clearing stale data after source edits or next-patient reset. There were no uncaught page errors, external requests or failed requests in this gate.

After these gates, only this verification document and its generated manifest change for the final archive. Final integrity checks compare the delivered archive to its source and confirm application code is byte-identical to the tested candidate. Original report images and browser screenshots are excluded from both archives.

## Remaining accuracy boundary

Detailed map colors and locally fitted 3D point readings may differ. The report-image minimum is consequently labeled Lowest reconstructed pachymetry; native data retain Lowest mapped pachymetry. Display estimates never move either source minimum or modify calculator results.

No paired native numerical Pentacam export was supplied for a device-level accuracy comparison. The existing numerical contract/converter is retained, but no universal proprietary export parser is claimed. Larger, clipped, boundary-connected and genuinely unsupported surface regions remain unavailable. A native-export sample with its reference/coordinate documentation is required for a verified device-specific adapter.
