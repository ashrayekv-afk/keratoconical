# Numerical corneal import — 9.1.2

The viewer can retain supplied numerical surface coordinates and independent device pachymetry. Its existing versioned JSON contracts are `nkpi-corneal-surface-1` and `nkpi-corneal-maps-1`. This release improves report-map display; it does not add an unverified proprietary Pentacam decoder.

## What an export needs to contain

Obtain one de-identified export from an examination with a matching source report. Useful content is:

- Anterior and posterior surface heights, preferably actual X/Y/Z coordinates in a shared declared frame.
- Spatial pachymetry and curvature maps with their measurement definitions.
- Grid positions or spacing, units, eye and examination association.
- Coverage/validity information and missing-value conventions.
- Reference-surface metadata when heights are expressed relative to a fitted surface.

A report JPG/PDF contains rendered colors and text. A summary CSV with K1, K2, Kmax or minimum pachymetry alone does not contain the spatial geometry. The extension `.csv`, `.dcm` or a proprietary backup suffix does not establish that readable pointwise fields are present. A numerical export can itself contain device interpolation or missing regions; preserve its documented provenance and validity.

Displayed elevation is relative to a reference surface. It must not be relabeled as absolute Z, and independently fitted front and back elevation maps must not be subtracted to obtain thickness. If only curvature/elevation map values are available, use the map-only contract and retain the unavailable patient-geometry state.

## Accepted coordinate contract

`components/cornea/surface_schema.js` validates the complete contract. It requires correct OD/OS and first/latest association; a corneal-vertex origin; explicit positive X/Y/Z directions; X/Y/Z in millimetres; curvature in dioptres; and elevation/pachymetry in micrometres. Source axes are strictly increasing before the viewer's declared orientation conversion. Missing entries use JSON `null`.

Anterior/posterior surfaces share the declared frame and axes. A surface entry requires actual `z_mm` values and at least a complete supported cell. Device `thickness_um` remains independent of the vertical or paired-point separation between those surfaces. Curvature maps declare axial, tangential, mean or device-reported type. Elevation maps declare reference type and fitting diameter. Existing numerical coordinates and point values are not filled by the small-gap display option.

## Pointwise CSV conversion

The existing standard-library script `tools/convert_surface_csv.py` accepts these exact, explicit headers:

```text
x_mm,y_mm,z_anterior_mm,z_posterior_mm,thickness_um,curvature_anterior_D,curvature_posterior_D,elevation_anterior_um,elevation_posterior_um
```

Only include columns actually supplied. X/Y and at least one actual Z surface column are required by this converter. Empty cells or literal `null` represent missing values. Duplicate coordinates, unknown columns, nonfinite values, ambiguous units and unsupported coordinate conventions are rejected. It does not infer a surface from summary indices or resample scattered points.

Inspect the converter's options with:

```bash
python tools/convert_surface_csv.py --help
```

Rename/reformat a device export into this contract only after its field definitions, units, coordinate axes and references have been verified. A successful format conversion does not independently establish measurement accuracy.

## Associate numerical data with the correct report

Place the verified numerical JSON in the report archive and add a root `nkpi-surface-index.json`. Its entries explicitly link the original report path to its surface JSON:

```json
{
  "schema": "nkpi-surface-index-1",
  "entries": [
    {
      "report": "exam/Report.jpg",
      "surface": "exam/cornea.surface.json"
    }
  ]
}
```

Replace the example paths with actual archive paths and supply the correct eye/visit inside the numerical file. The source association must match the verified calculator slot. The extractor also supports an unambiguous matching `.surface.json` companion name. See `docs/MAP_COMPARISON.md` and `docs/REGIONAL_CHANGE.md` for established association and longitudinal rules.

After import, confirm the source label and orientation, inspect the supplied values and missing-data regions, and compare the result against the same examination in the device software. Do not substitute the other eye, another visit, or a summary scalar at an unknown coordinate.

## Documentation basis

- OCULUS describes reference-relative elevation and the distinction from pachymetry in its [Pentacam Interpretation Guide](https://www.pentacam.com/fileadmin/user_upload/pentacam.de/downloads/interpretations-leitfaden/Pentacam_Interpretation_Guide_Ophth_EN_0624.pdf), section 3.2.2.1.
- The primary [OKULIX integration manual](https://www.okulix.de/okulix-en.pdf), sections 1.6.3 and 2.3, documents Pentacam transfer of topography and spatial pachymetry. Its pictured export preferences do not establish the exact menu, file structure or entitlement on every clinic installation.
- OCULUS [Instructions for Use](https://www.oculus.de/us/?action=custom_download&id=69), section 6.6, describe acquisition-quality limitations including incomplete analyzed area and lost segments.

These sources establish the importance and feasibility of numerical data. Compatibility with a specific clinic export still requires the actual sample and its applicable documentation.
