# Integrated corneal viewer and source contract — 9.1.2

This document describes the current integrated viewer. The frozen NKPI calculator, regional comparison calculations, and cone tracking remain separate from this presentation model.

## One model with independent attributes

OD and OS share camera controls and the same physical scale. Whole surface and Section display the same retained coordinates. Point selection and map tint do not deform the cornea. Each selected original grid node can expose five independent fields: thickness, anterior curvature, posterior curvature magnitude, anterior elevation, and posterior elevation. Summary scalars such as Kmax, ARC, PRC, BAD-D, ARTmax, and NKPI do not generate extra deformations.

The natural view uses lighting and a translucent material. Measurement views use opaque, unlit colors on the same supported surface, with gray for unavailable map values. A numbered legend, units and a selected-value marker explain each scale. Optional contour bands follow displayed numerical levels. Colors encode values, not clinical categories or a validated cone boundary.

Color bounds are held across compatible eyes and visits in the imported case. Source provenance and map definitions determine compatibility; different definitions retain separately labeled scales. Signed elevation has a symmetric scale with a neutral zero. Curvature progresses from lower cool colors to higher warm colors; thickness reverses this direction so smaller values are warm. Display bounds round outward to include the retained values with five evenly spaced ticks; they are not measured extrema, input calibration limits or clinical thresholds. Presentation interpolation does not create additional numerical point readings.

The white globe, iris, pupil, and peripheral cornea are reference anatomy. Their assumed dimensions and placement are for visual context. They are not measurements of this patient's whole eye. The renderer does not simulate patient refraction, optical aberrations, glare, or visual acuity.

## Source association

Each report is bound to an eye, visit, and verified calculator input snapshot. Source edits, changed measurements, an eye being removed, and next-patient clearing invalidate that association. The viewer never substitutes the other eye or another visit. A missing selected visit remains unavailable.

Priority is given to a valid native numerical surface. Otherwise, usable report elevation and a verified reference sphere can supply approximate anterior geometry. Maps without height data keep their available point values, while the view explicitly states that patient surface geometry is unavailable. An absent report supplies no patient readings.

The runtime has no embedded example patient or demo-eye selector. Browser source images and grids are not included in the release archive or transmitted as calculator inputs.

## Native numerical coordinates

The existing `nkpi-corneal-surface-1` and `nkpi-corneal-maps-1` contracts are validated by `cornea/surface_schema.js`. They require:

- `kind: measured`, `source: device_numeric_export`, correct `eye` and `visit`.
- Increasing source `x_mm` and `y_mm` arrays with explicit units and missing values represented by `null`.
- A corneal-vertex origin and declared temporal/nasal, superior/inferior, and anterior/posterior directions.
- Corresponding anterior and optional posterior fields on the same coordinate axes.
- Curvature definitions and elevation-reference metadata for the supplied maps.
- Valid complete cells for a renderable numerical surface.

The adapter converts declared orientation to the viewer frame. Positive y is superior. Positive x is nasal in OD and temporal in OS. This orientation conversion may make viewer axes descend; dimensions remain unchanged. The circular aperture is limited by the supplied axis extents and the existing six-millimetre radius limit.

Native front and available back coordinates retain their supplied values at supported nodes. Device pachymetry is independent. The distance between paired front/back coordinates must not be relabeled as pachymetry. The native selected-point annotation uses a front marker and a device-thickness label, without implying that a line to the back surface measures that value.

A native map-only export has numerical map values but no patient height geometry. Its internal reference grid supports point indexing; the integrated view states that surface geometry is unavailable. It is not registered to report pixels by matching array dimensions. Missing native height samples are not fabricated. Missing native posterior coordinates remain unavailable in this viewer.

See `NUMERICAL_IMPORT.md`, `MAP_COMPARISON.md` and `REGIONAL_CHANGE.md` for the existing `nkpi-surface-index.json` association workflow. These JSON contracts do not imply support for every proprietary device export.

## Report-image calibration

The automatic report route is limited to supported original Pentacam export layouts, including proportional scaling, with intact titles and legends. Phone photographs, cropped legends, rotated/mirrored pages, and undocumented layouts are not calibrated by guessing.

The standard anterior elevation map and its floating BFS are used. Enhanced, exclusion, and difference maps are not interchangeable. The reader checks map identity, printed BFS radius, plotting diameter, legend units, and the signed elevation scale. The plotting diameter is distinct from the BFS fitting diameter.

The reader retains the accepted legend anchors and calibrated range. These may be narrower than the full printed scale if an outer label cannot be corroborated. No unaccepted endpoint is silently added. A fresh import is required when an older report object lacks the calibration metadata needed for the integrated reconstruction.

The existing 41-by-41 grid samples the central two-thirds of the plotting radius for regional calculations. A separate 61-by-61 display field samples the actual full printed circle. A nine-millimetre plot can therefore provide a nine-millimetre viewer field while its central grid covers six millimetres. A smaller supported field is never stretched across the iris.

Fresh imports additionally retain an optional `display_detail` object with schema `nkpi-report-detail-grid-1`: a 121-by-121 field over the same full printed circle. Its samples use the same accepted palette and source-color checks, with an RGB decode cache for performance. A strict validator checks dimensions, diameter, coverage, value intervals, sampling provenance and aperture. This field is used only for quantitative map presentation. It does not replace the 41-by-41 regional grid, the 61-by-61 reconstruction grid, reconstructed coordinates, point readings or numerical minima. Older sources without the detailed field retain their accepted existing map grids.

The integrated adapter clones these fields. Color intervals touching an accepted calibration endpoint are conservatively excluded because a clipped color can represent an out-of-range value. Original samples, missing masks, and regional inputs are not overwritten.

## Independent map display and small-gap estimates

`integrated_model.js` adds independent `displayMaps` descriptors containing physical bounds, increasing X/Y axes, source values and validity/censoring status. Report row order is converted into positive-superior Y. Radius-unit curvature is converted using the existing map definition. This metadata does not modify any retained vertex, triangle, geometry or selected-point field.

`integrated_coverage.js` prepares each map on the retained source mesh. Unsupported geometry, the source aperture and missing/censored map samples remain separately accounted for. The renderer uses source-sample footprints rather than making an entire geometry triangle unavailable because a single corner lacks its selected map value. Complete supported stencils allow display interpolation. Otherwise, a valid nearest sample retains its own footprint and a missing nearest sample retains its missing footprint. Source footprints are a raster display convention, not additional measured points.

The **Estimate small gaps** control is initially enabled for quantitative maps. It adds only separate display values to eligible small enclosed components. The present engineering policy is:

- Maximum component span, including its sample footprint: 0.30 mm in either axis.
- Maximum component area: 0.075 mm².
- Original directly sampled donors within 0.45 mm, with at least eight donors covering all four quadrants.
- A local weighted-plane fit whose residual does not exceed 0.6 of the median supporting color-interval width.
- An estimate bounded by the minimum and maximum supporting donor values.

These are software acceptance rules, not clinical thresholds. Clipped samples, components touching clipped neighbors, boundaries, large gaps, absent source geometry and missing native numerical data are excluded. Existing locally recovered report colors are not used as interpolation donors. Earlier fills never become donors for later fills. Inconsistent or insufficient fits abstain. An unseen extremum cannot be recovered merely by fitting a smooth neighborhood.

Status codes distinguish unavailable, imported source support, additional estimate and clipped data. Additional estimates have a subtle visible pattern, a separate selected-point note and corresponding PNG provenance. Disabling the control restores the source-supported display mask. The source arrays, five source point readings, reconstructed minimum, scale extrema and NKPI inputs do not change with this control.

Coverage percentages use map sample locations on the retained supported surface. Source/report support, added estimates and unavailable samples sum to 100% of that denominator; clipped cells are included in unavailable. Source geometry that does not exist is excluded from the denominator and stays visibly open. Coverage is not accuracy, whole-eye coverage or a guarantee of a complete cornea.

Color scales include both retained source-point ranges and the detailed supported map ranges, with compatible sources held across eyes and visits. Added estimates never expand the scales. Exact constant native fields are copied without resampling roundoff; negligible machine-precision range differences do not become exaggerated display contrast. Original numerical native coordinates and readings remain exact. A nonuniform native grid can be resampled for presentation only through complete supported stencils; missing native values are not gap-filled.

Detailed report colors and locally fitted reconstructed point readings can differ. The inspector identifies a distinct report-color sample separately when it differs beyond displayed precision or when the original point field is unavailable. Neither a detailed color sample nor an additional estimate replaces the source point value. The report-image minimum is labeled **Lowest reconstructed pachymetry**. Native numerical sources retain **Lowest mapped pachymetry**, meaning the smallest usable supplied source-grid value.

## Approximate front and inner geometry

The front is a centered, untilted reference sphere plus the signed anterior elevation. Millimetres and micrometres are converted explicitly. The report does not supply the floating sphere's complete translation and tilt, so this is an approximation.

A weighted local plane smooths readable elevation and pachymetry within a 0.6 mm neighborhood. It retains the existing requirements: at least six samples, at least 50% local support, and a nearby source sample within the existing grid-dependent distance bound. This can recover small printed-label obstructions; it cannot restore a known clipped value.

A complete model requires at least 50% usable support within its chosen aperture. The full display field is attempted first, with a central-field fallback when appropriate. If conservative censoring causes the complete-model gate to fail, the viewer may show only locally supported patches in the previously accepted aperture. It records the original rejection and labels the result **Partial report-image reconstruction**. These are software processing rules, not clinical accuracy thresholds.

Known clipped front cells are removed after fitting so neighboring samples cannot fill them back. Triangles require supported vertices; unsupported regions remain open. No harmonic surface completion is used within the patient source field by this integrated viewer.

When matching pachymetry exists, the front is offset inward along its reconstructed local normal by the retained thickness. The full three-dimensional distance equals that thickness; the method does not use a vertical z-only gap. This is a thickness-derived inner boundary, not an independently measured posterior surface. Missing or censored pachymetry leaves the corresponding inner point unavailable. Mismatched plot diameters and ambiguous duplicate thickness maps are not combined.

## Independent posterior elevation

A standard posterior elevation map has its own floating BFS. Its radius, map identity, plotting diameter, and signed legend are checked separately. Generic OCR crops and repeated source reads are used; no patient-specific header values or manual transcriptions are embedded in production code.

Posterior elevation is an x/y point attribute. It never replaces absolute posterior z coordinates or generates front/back separation. The fitting diameter remains separate from the plotting diameter and may be unavailable if unreadable.

After endpoint censoring, a sparse posterior field may still provide a point value where the entire interpolation stencil is supported and uncensored. Its sparse status is retained. This local attribute does not turn an incomplete posterior map into an accepted complete surface.

Anterior report radii are converted to dioptres using 337.5/r. Posterior radius values use 40/r and are labeled as magnitude, |D|. Native posterior dioptres retain their supplied field but are displayed consistently as magnitude in that mode. Elevation retains its sign. Report-derived readouts carry the approximate marker.

## Reference anatomy and viewing

Reference peripheral tissue is outside the sampled aperture. A transition supplies visual context toward a reference limbus and globe without moving retained patient vertices. No point measurements are assigned to that reference tissue. Unavailable regions within the source field remain open rather than being labeled as measured tissue.

The Section setting removes part of the displayed shell to expose the available interior. It is a viewing cut, not pathology. Its radial edge is aligned with that eye/visit's lowest supported mapped pachymetry. Cut walls follow retained mesh adjacency and supported front/back points. Point X/Y controls select existing grid indices and do not deform the surface. A manually chosen point within the viewing cut retains its numerical readings; the viewer directs the user to Whole surface instead of placing a floating caliper in the opening.

The initial selection minimizes finite positive mapped thickness among supported vertices with valid front coordinates. It does not favor points with more available measurements. Equal minima use a deterministic central-distance/index tie break. Each eye and visit has an independent selection; changing the displayed field preserves it, and Thinnest point resets it. If thickness is unavailable, the viewer keeps an explicit unavailable state and does not infer a minimum from another field.

For report images, this is **Lowest reconstructed pachymetry**, the minimum of the supported reconstructed samples. Color quantization, local fitting and incomplete support can make it differ from the source report's scalar C or the finer color-display field. A scalar minimum without its validated spatial location cannot establish a 3D position, so it is never substituted at a different node. The selected minimum is not assumed to coincide with maximum curvature, maximum elevation or a validated cone apex.

A locally supported sample can be isolated from the retained triangle mesh when neighboring source cells are unavailable. Its lower thickness remains the selected minimum; it is not replaced by a thicker connected node. The viewer labels the surrounding surface as unavailable and uses a point-only annotation instead of inventing triangles or a tissue caliper. This is distinct from a valid surface point temporarily hidden by the Section viewing cut.

The renderer uses local WebGL without external textures. A Canvas fallback displays the supported source mesh with simpler material effects when WebGL cannot initialize. Source measurements remain available if the graphics context is interrupted. Disposal releases listeners, observers, and graphics resources when the source or visit changes.

Native and report geometry use the same units on all axes. Both eye panels use the same pixels per millimetre, including when their CSS dimensions differ slightly. There is no artificial elevation amplification in this integrated view. Earlier and latest reconstructions are independent, not registered tissue motion.

The PNG export includes both views, selected point values and minimum-selection status, visit, source status, limitations, numerical color legends, map coverage and display-estimate state. It does not include source report images or patient identifiers.

## Accuracy boundary

A convincing appearance does not establish patient accuracy. Printed color quantization, unreadable areas, clipped scales, unknown reference pose, and scan repeatability limit report reconstruction. Native coordinates support closer corneal geometry but do not measure the iris or entire globe. The viewer is not a clinically validated surgical-planning surface or optical model.

Background on elevation references and curvature:

Belin and Khachikian, 2008, *An introduction to understanding elevation-based topography: how elevation data are displayed*.
https://www.pentacam.com/fileadmin/user_upload/pentacam.de/downloads/publikationen/artikel/2008-Article__Pentacam_An_introduction_understand_elevation_based_topography.pdf

Color-scale background: Matplotlib, *Choosing Colormaps*, describes sequential scales for ordered values and diverging scales around a meaningful midpoint.
https://matplotlib.org/stable/users/explain/colors/colormaps.html

The software behavior is defined by `integrated_model.js`, `image_regions.js`, `patient_shape.js`, `integrated_measurements.js`, and `integrated_eye.js`. See `TEST_REPORT.md` for verification scope and limits.
