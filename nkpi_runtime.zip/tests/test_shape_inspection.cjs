'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const S = require('../components/cornea/shape_inspection.js');
let count = 0;
const near = (a, b, tolerance = 1e-9) => assert.ok(Math.abs(a - b) <= tolerance, `${a} != ${b}`);
function test(name, run) { run(); count++; console.log('PASS', name); }

// Entirely synthetic surfaces; no patient scans or diagnostic thresholds.
function fixture(options = {}) {
  const axis = Array.from({length: 13}, (_, i) => (i - 6) / 2);
  const xs = options.xs || axis, ys = options.ys || axis;
  const r = options.radius || 3, R = options.bfs || 7.8;
  const elevation = options.elevation || (() => 0);
  const thickness = options.thickness || (() => 500);
  const m = {kind: options.kind || 'estimated', nx: xs.length, ny: ys.length,
    axisX: xs.slice(), axisY: ys.slice(), radius: r, bfs: R,
    legend_step: options.legend_step === undefined ? 5 : options.legend_step, vertices: []};
  for (const y of ys) for (const x of xs) {
    if (Math.hypot(x, y) > r + 1e-10) { m.vertices.push(null); continue; }
    const e = elevation(x, y), t = thickness(x, y);
    const z = options.height ? options.height(x, y)
      : Math.sqrt(R * R - x * x - y * y) - R + (Number.isFinite(e) ? e / 1000 : 0);
    m.vertices.push({front: [x, y, z], back: [x - .02, y + .03, z - .45],
      thickness: t, elevation: e, interpolated: false});
  }
  return m;
}
const indexAt = (m, x, y) => m.axisY.indexOf(y) * m.nx + m.axisX.indexOf(x);
const vertexAt = (m, x, y) => m.vertices[indexAt(m, x, y)];
const cone = (x, y) => 100 * Math.exp(-((x - 1) ** 2 + (y + .5) ** 2) / .25);

test('CommonJS and browser script expose only the four source-inspection helpers', () => {
  assert.deepEqual(Object.keys(S).sort(), ['peak', 'profileAngle', 'sample', 'section']);
  const context = {window: {}};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../components/cornea/shape_inspection.js'), 'utf8'), context);
  assert.equal(typeof context.window.NKPIShapeInspection.section, 'function');
});

test('Supported off-axis elevation selects the actual sample and its meridian', () => {
  const m = fixture({elevation: cone}), p = S.peak(m);
  assert.equal(p.index, indexAt(m, 1, -.5));
  assert.equal(p.x, 1); assert.equal(p.y, -.5); near(p.elevation_um, 100);
  near(S.profileAngle(m), Math.atan2(-.5, 1));
  assert.equal(p.resolution_um, 5); assert.equal(p.resolved, true);
  assert.ok(p.contrast_um > 99 && p.contrast_um <= 100);
});

test('Zero, negative and unavailable elevation never acquire a fabricated peak', () => {
  for (const elevation of [() => 0, () => -10, () => null])
    assert.equal(S.peak(fixture({elevation})), null);
  assert.equal(S.peak(null), null);
  near(S.profileAngle(fixture()), 0);
});

test('Direct supported peaks take priority over interpolated local estimates', () => {
  const m = fixture({elevation: cone});
  vertexAt(m, -.5, 0).elevation = 500;
  vertexAt(m, -.5, 0).interpolated = true;
  assert.equal(S.peak(m).index, indexAt(m, 1, -.5));
  for (const v of m.vertices) if (v) v.interpolated = true;
  assert.equal(S.peak(m).index, indexAt(m, -.5, 0));
});

test('Reference/fill vertices and points outside the measured aperture are excluded', () => {
  const m = fixture({elevation: cone});
  vertexAt(m, 0, 0).elevation = 900;
  vertexAt(m, 0, 0).provenance = 'filled';
  vertexAt(m, -.5, 0).elevation = 1000;
  vertexAt(m, -.5, 0).provenance = 'reference';
  vertexAt(m, -1, 0).elevation = 1100;
  vertexAt(m, -1, 0).sourceId = -1;
  m.vertices.push({front: [5, 5, 0], elevation: 10000, thickness: 400});
  assert.equal(S.peak(m).index, indexAt(m, 1, -.5));
  m.vertices.pop();
  assert.equal(S.sample(m, 0, 0), null);
  m.dataRadius = 1;
  assert.notEqual(S.peak(m)?.index, indexAt(m, 1, -.5));
});

test('Uniform offsets and printed-step boundaries stay descriptive and unresolved', () => {
  const m = fixture({elevation: () => 10, legend_step: 10}), p = S.peak(m);
  near(p.x, 0); near(p.y, 0); near(p.contrast_um, 0); assert.equal(p.resolved, false);
  const bounded = fixture({legend_step: 10});
  vertexAt(bounded, 1, 0).elevation = 10;
  assert.equal(S.peak(bounded).resolved, false);
  bounded.legend_step = 9;
  assert.equal(S.peak(bounded).resolved, true);
  delete bounded.legend_step;
  assert.equal(S.peak(bounded).resolution_um, null);
  assert.equal(S.peak(bounded).resolved, null);
});

test('Native heights without elevation use the actual thinnest supported location', () => {
  const m = fixture({kind: 'native', elevation: () => null,
    thickness: (x, y) => 450 + 20 * ((x + 1) ** 2 + (y - .5) ** 2)});
  assert.equal(S.peak(m), null);
  near(S.profileAngle(m), Math.atan2(.5, -1));
  vertexAt(m, 1, 1).thickness = 100;
  vertexAt(m, 1, 1).interpolated = true;
  near(S.profileAngle(m), Math.atan2(.5, -1));
});

test('Bilinear sampling preserves supplied coordinates and independent field values', () => {
  const m = fixture({kind: 'native', height: (x, y) => 2 + .2 * x - .4 * y,
    elevation: (x, y) => 5 + .7 * x - .2 * y,
    thickness: (x, y) => 500 + 20 * x + 30 * y});
  const p = S.sample(m, .25, -.25);
  near(p.front[0], .25); near(p.front[1], -.25); near(p.front[2], 2.15);
  near(p.back[0], .23); near(p.back[1], -.22); near(p.back[2], 1.70);
  near(p.thickness, 497.5); near(p.elevation, 5.225);
});

test('Descending axes preserve anatomical coordinates without an extra eye mirror', () => {
  const axes = Array.from({length: 13}, (_, i) => (i - 6) / 2);
  for (const reverseX of [false, true]) for (const reverseY of [false, true]) {
    const m = fixture({xs: reverseX ? axes.slice().reverse() : axes,
      ys: reverseY ? axes.slice().reverse() : axes, kind: 'native',
      height: (x, y) => 2 + .2 * x - .4 * y, elevation: cone});
    for (const eye of ['OD', 'OS']) {
      m.eye = eye;
      const p = S.sample(m, .25, -.25);
      near(p.front[2], 2.15);
      near(S.peak(m).x, 1); near(S.peak(m).y, -.5);
      near(S.profileAngle(m), Math.atan2(-.5, 1));
    }
  }
});

test('Missing source spans remain null, while exact supported grid nodes remain usable', () => {
  const m = fixture();
  for (const y of m.axisY) m.vertices[indexAt(m, 0, y)] = null;
  assert.equal(S.sample(m, -.25, 0), null);
  assert.equal(S.sample(m, 0, 0), null);
  assert.equal(S.sample(m, .25, 0), null);
  assert.ok(S.sample(m, -.5, 0)); assert.ok(S.sample(m, .5, 0));
  const line = S.section(m, 0, 25);
  assert.equal(line.points[11], null); assert.equal(line.points[12], null);
  assert.equal(line.points[13], null); assert.ok(line.points[10]); assert.ok(line.points[14]);
});

test('Circular support, axis limits and invalid grids cannot be extrapolated', () => {
  const m = fixture();
  assert.equal(S.sample(m, 2.75, 2.75), null);
  assert.equal(S.sample(m, 3.01, 0), null);
  assert.equal(S.sample(m, NaN, 0), null);
  assert.ok(S.sample(m, 3, 0));
  const short = fixture({xs: [-1, 0, 1], ys: [-1, 0, 1]});
  assert.equal(S.sample(short, 1.25, 0), null);
  short.axisX[1] = short.axisX[0];
  assert.equal(S.sample(short, 0, 0), null);
  const mismatched = fixture(); mismatched.vertices.pop();
  assert.equal(S.sample(mismatched, 0, 0), null);
});

test('Missing optional back/thickness/elevation stay null without erasing valid front data', () => {
  const m = fixture({elevation: () => 10}), v = vertexAt(m, .5, .5);
  v.back = null; v.thickness = null; v.elevation = null;
  const p = S.sample(m, .25, .25);
  assert.ok(p.front); assert.equal(p.back, null);
  assert.equal(p.thickness, null); assert.equal(p.elevation, null);
  assert.ok(S.sample(m, 0, 0).back);
});

test('Image sections use the original centered BFS sag and retain explicit gap positions', () => {
  const m = fixture({elevation: cone}), angle = S.profileAngle(m);
  const line = S.section(m, angle, 121);
  near(line.angle, angle); assert.equal(line.points.length, 121);
  assert.deepEqual(line.peak, S.peak(m));
  for (const p of line.points) if (p) {
    near(p.front[0], p.distance * Math.cos(angle));
    near(p.front[1], p.distance * Math.sin(angle));
    near(p.reference_z, Math.sqrt(m.bfs ** 2 - p.distance ** 2) - m.bfs);
  }
  near(line.points[60].reference_z, 0);
});

test('Native sections never assume a BFS origin or manufacture missing elevation', () => {
  const m = fixture({kind: 'native', height: (x, y) => 2 + .2 * x - .4 * y,
    elevation: () => null});
  const line = S.section(m, Math.PI / 2, 13);
  assert.equal(line.peak, null);
  for (const p of line.points) if (p) {
    assert.equal(p.reference_z, null); assert.equal(p.elevation, null);
    near(p.front[2], 2 - .4 * p.distance);
  }
});

test('Reference-only and display-completion models expose no invented source sections', () => {
  for (const m of [fixture({kind: 'reference', elevation: cone}),
    {...fixture({elevation: cone}), isAnatomy: true}]) {
    assert.equal(S.peak(m), null); near(S.profileAngle(m), 0);
    assert.equal(S.sample(m, 0, 0), null);
    assert.ok(S.section(m, 0).points.every(p => p === null));
  }
  assert.ok(S.section(null, NaN).points.every(p => p === null));
  assert.throws(() => S.section(fixture(), 0, 1), RangeError);
  assert.throws(() => S.section(fixture(), 0, 2002), RangeError);
});

test('Inspection does not mutate source arrays or return writable coordinate aliases', () => {
  const m = fixture({elevation: cone}), before = JSON.stringify(m);
  function freeze(value) {
    if (value && typeof value === 'object') { Object.values(value).forEach(freeze); Object.freeze(value); }
  }
  freeze(m);
  S.peak(m); S.profileAngle(m);
  const point = S.sample(m, 0, 0), line = S.section(m, .3);
  point.front[0] = 999; point.back[2] = 999;
  line.points.find(Boolean).front[2] = 999;
  assert.equal(JSON.stringify(m), before);
});

// Numerical renderer integration checks. These inspect production transforms
// and drawing commands; they do not substitute for actual canvas visual QA.
const Shape = require('../components/cornea/patient_shape.js');
function geometry(options = {}) {
  const m = fixture(options);
  m.triangles = [];
  for (let j = 0; j < m.ny - 1; j++) for (let i = 0; i < m.nx - 1; i++) {
    const a = j * m.nx + i, b = a + 1, c = a + m.nx, d = c + 1;
    for (const ids of [[a, b, c], [b, d, c]]) if (ids.every(k => m.vertices[k])) m.triangles.push(ids);
  }
  const points = m.vertices.filter(Boolean);
  m.centerZ = points.reduce((sum, v) => sum + v.front[2], 0) / points.length;
  m.coverage = 1; m.possible = points.length; m.interpolated = 0;
  return Shape.prepare(m);
}

test('1×/3×/6× relief changes only supported elevation departure and preserves tissue separation', () => {
  const m = geometry({elevation: cone, thickness: (x, y) => 500 + 20 * x + 10 * y});
  const original = JSON.stringify(m.vertices), overlays = JSON.stringify(m.overlays);
  assert.equal(Shape.emphasizeElevation(m, 1), m);
  for (const factor of [3, 6]) {
    const emphasized = Shape.emphasizeElevation(m, factor);
    for (let i = 0; i < m.vertices.length; i++) {
      const a = m.vertices[i], b = emphasized.vertices[i];
      if (!a) { assert.equal(b, null); continue; }
      const dz = (factor - 1) * a.elevation / 1000;
      near(b.front[0], a.front[0]); near(b.front[1], a.front[1]);
      near(b.front[2] - a.front[2], dz); near(b.back[2] - a.back[2], dz);
      for (let k = 0; k < 3; k++) near(b.back[k] - b.front[k], a.back[k] - a.front[k]);
      assert.equal(b.thickness, a.thickness); assert.equal(b.elevation, a.elevation);
    }
    assert.deepEqual(S.peak(emphasized), S.peak(m));
  }
  assert.equal(JSON.stringify(m.vertices), original);
  assert.equal(JSON.stringify(m.overlays), overlays);
  for (const kind of ['native', 'reference']) {
    const model = geometry({kind, elevation: cone});
    assert.equal(Shape.emphasizeElevation(model, 6), model);
  }
});

test('Relief variants and drag meshes are cached and remain separate from original geometry', () => {
  const m = geometry({elevation: cone});
  const a = Shape.emphasizeElevation(m, 3), b = Shape.emphasizeElevation(m, 6);
  assert.equal(Shape.emphasizeElevation(m, 3), a);
  assert.equal(Shape.emphasizeElevation(m, 6), b);
  assert.notEqual(a, b);
  const full = Shape.anatomicalMesh(b), coarse = Shape.interactiveMesh(b);
  assert.equal(Shape.anatomicalMesh(b), full); assert.equal(Shape.interactiveMesh(b), coarse);
  assert.ok(coarse.vertices.length < full.vertices.length / 2);
  const state = {eyeContext: false, yaw: -1.2, pitch: -.1, roll: .7, zoom: 1.2};
  const sourcePoint = vertexAt(b, 1, -.5).front;
  assert.deepEqual(Shape.project(coarse, sourcePoint, state), Shape.project(full, sourcePoint, state));
  Shape.prepare(m);
  assert.notEqual(Shape.emphasizeElevation(m, 3), a, 'Source preparation invalidates an obsolete relief cache');
});

test('Eye detail frames the anatomical limbus with equal spatial units and consistent rotation', () => {
  const m = geometry({elevation: cone}), display = Shape.anatomicalMesh(m);
  const state = {eyeContext: false, yaw: 0, pitch: 0, roll: 0, zoom: 1};
  const origin = [0, 0, display.focusZ], p = Shape.project(display, origin, state);
  const x = Shape.project(display, [1, 0, display.focusZ], state);
  const y = Shape.project(display, [0, 1, display.focusZ], state);
  near(x[0] - p[0], p[1] - y[1]); near(p[3], Math.min(410, 680 * .36) / display.radius);
  near(p[3] / Shape.project(display, origin, {...state, eyeContext: true})[3], 12 / display.radius);
  for (const angle of [-2.5, -.7, 0, .8, 2.5]) {
    const roll = -Math.PI / 2 - angle;
    const radial = Shape.rotate([Math.cos(angle), Math.sin(angle), 0], -1.48, 0, roll);
    near(radial[0], 0); near(radial[1], -1); near(radial[2], 0);
    const anterior = Shape.rotate([0, 0, 1], -1.48, 0, roll);
    assert.ok(anterior[0] < -.99); near(Math.hypot(...anterior), 1);
  }
});

test('Thickness contour values stay fixed while drawing coordinates follow the relief transform', () => {
  const elevation = (x, y) => 40 + 8 * x + 6 * y;
  const m = geometry({elevation, thickness: (x, y) => 500 + 30 * x + 10 * y});
  const original = Shape.thicknessContours(Shape.displayMesh(m));
  assert.ok(original.length > 20);
  for (const factor of [3, 6]) {
    const transformed = Shape.thicknessContours(Shape.displayMesh(Shape.emphasizeElevation(m, factor)));
    assert.equal(transformed.length, original.length);
    for (let i = 0; i < original.length; i++) {
      assert.equal(transformed[i].level, original[i].level);
      for (let j = 0; j < 2; j++) {
        const a = original[i].points[j], b = transformed[i].points[j];
        near(a[0], b[0]); near(a[1], b[1]);
        near(b[2] - a[2], (factor - 1) * elevation(a[0], a[1]) / 1000);
      }
    }
  }
});

function drawingCanvas(width = 1000, height = 340) {
  const operations = [], context = {
    path: [], dash: [],
    fillRect() {},
    fillText(text, x, y) { operations.push({type: 'text', text, x, y}); },
    beginPath() { this.path = []; },
    moveTo(x, y) { this.path.push({type: 'move', x, y}); },
    lineTo(x, y) { this.path.push({type: 'line', x, y}); },
    closePath() { this.path.push({type: 'close'}); },
    arc(x, y, r) { this.path.push({type: 'arc', x, y, r}); },
    setLineDash(dash) { this.dash = dash.slice(); },
    stroke() { operations.push({type: 'stroke', color: this.strokeStyle, dash: this.dash.slice(), path: this.path.slice()}); },
    fill() { operations.push({type: 'fill', color: this.fillStyle, path: this.path.slice()}); }
  };
  return {width, height, operations, getContext: () => context};
}
const trace = (canvas, color) => canvas.operations.find(p => p.type === 'stroke' && p.color === color).path;

test('Cross-section rendering preserves gap breaks rather than drawing over absent source spans', () => {
  const m = geometry();
  for (const y of m.axisY) m.vertices[indexAt(m, 0, y)] = null;
  const canvas = drawingCanvas(), result = Shape.renderSection(canvas, m, {angle: 0});
  assert.ok(result.points.some(p => p === null));
  for (const color of ['#b9edf4', '#d6b786', '#91a1b8'])
    assert.equal(trace(canvas, color).filter(p => p.type === 'move').length, 2);
  assert.ok(canvas.operations.some(p => p.type === 'text' && p.text === 'TRUE SCALE · EQUAL PHYSICAL AXES'));
});

test('Cross-section 1×/3×/6× uses one physical scale, transforms both surfaces and leaves BFS unchanged', () => {
  const m = geometry({elevation: (x, y) => 20 + 5 * x}), before = JSON.stringify(m.vertices);
  const source = S.section(m, 0).points;
  for (const factor of [1, 3, 6]) {
    const canvas = drawingCanvas(), result = Shape.renderSection(canvas, m, {angle: 0, emphasis: factor});
    assert.equal(result.factor, factor); assert.deepEqual(result.points, source);
    const front = trace(canvas, '#b9edf4'), back = trace(canvas, '#d6b786'), reference = trace(canvas, '#91a1b8');
    assert.equal(front.length, source.length);
    const center = 60, next = 80;
    near((front[next].x - front[center].x) / result.scale, 1);
    const actualChange = source[next].front[2] - source[center].front[2];
    near((front[center].y - front[next].y) / result.scale,
      actualChange + (factor - 1) * (source[next].elevation - source[center].elevation) / 1000);
    near((back[next].y - front[next].y) / result.scale, .45);
    near((reference[center].y - reference[next].y) / result.scale,
      source[next].reference_z - source[center].reference_z);
    if (factor > 1) assert.ok(canvas.operations.some(p => p.type === 'text' &&
      p.text === 'ELEVATION DEVIATION ×' + factor + ' · DISPLAY ONLY'));
  }
  assert.equal(JSON.stringify(m.vertices), before);
});

test('Native cross-section rendering does not activate relief or an assumed reference curve', () => {
  const m = geometry({kind: 'native', elevation: () => null,
    height: (x, y) => 2 + .2 * x - .4 * y});
  const canvas = drawingCanvas(), result = Shape.renderSection(canvas, m, {angle: 0, emphasis: 6});
  assert.equal(result.factor, 1);
  assert.ok(!canvas.operations.some(p => p.type === 'stroke' && p.color === '#91a1b8'));
  assert.ok(canvas.operations.some(p => p.type === 'text' && p.text === 'TRUE SCALE · EQUAL PHYSICAL AXES'));
});

test('Alternate section angles do not project an off-meridian elevation peak into the section', () => {
  const m = geometry({elevation: cone});
  const off = drawingCanvas();
  Shape.renderSection(off, m, {angle: 0});
  assert.ok(!off.operations.some(p => p.type === 'fill' && p.color === '#f6ddb0'));
  assert.ok(!off.operations.some(p => p.type === 'text' && p.text === 'Meridian through highest supported anterior elevation'));
  const aligned = drawingCanvas();
  Shape.renderSection(aligned, m, {angle: S.profileAngle(m) + Math.PI});
  assert.equal(aligned.operations.filter(p => p.type === 'fill' && p.color === '#f6ddb0').length, 1);
});

console.log(`${count} source-shape inspection and renderer test groups passed.`);
