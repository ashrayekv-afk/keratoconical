'use strict';
// Engineering checks and spatial holdouts; these do not establish clinical
// accuracy, particularly when an unseen extremum lies inside a missing patch.
const assert=require('node:assert/strict');
const C=require('../components/cornea/integrated_coverage.js');
const A=require('../components/cornea/integrated_model.js');
const M=require('../components/cornea/integrated_measurements.js');
let count=0;
const test=(name,fn)=>{fn();count++;console.log('PASS '+name);};
const close=(a,b,tolerance=1e-8)=>assert(Math.abs(a-b)<tolerance,`${a} != ${b}`);
const freeze=value=>{if(value&&typeof value==='object'){Object.freeze(value);Object.values(value).forEach(freeze);}return value;};
function fixture({n=41,r=2,field='anterior',fn=(x,y)=>45+2*x-y,sourceKind='report-image',bin=2}={}){
 const axis=Array.from({length:n},(_,i)=>-r+2*r*i/(n-1)),values=[],status=[],sampling=[],intervalWidths=[],vertices=[],triangles=[];
 for(let j=0;j<n;j++)for(let i=0;i<n;i++){
  const x=axis[i],y=axis[j],inside=Math.hypot(x,y)<=r+1e-8,value=inside?fn(x,y):null;
  values.push(value);status.push(inside?1:0);sampling.push(inside?'direct':null);intervalWidths.push(inside?bin:null);
  vertices.push(inside?{front:[x,y,-.06*(x*x+y*y)],back:null,thickness:480+10*x+4*y,[field]:value}:null);
 }
 for(let j=0;j<n-1;j++)for(let i=0;i<n-1;i++){const a=j*n+i,b=a+1,c=a+n,d=c+1;for(const ids of [[a,b,c],[b,d,c]])if(ids.every(k=>vertices[k]))triangles.push(ids);}
 const descriptor={schema:'nkpi-integrated-display-map-1',field,width:n,height:n,xMin:-r,xMax:r,yMin:-r,yMax:r,radius_mm:r,axisX:[...axis],axisY:[...axis],values,status,sampling,intervalWidths,sourceKind,detail:'original-map-detail'};
 const model={kind:sourceKind==='native'?'native':'estimated',mapSource:sourceKind==='native'?'native':'image',sourceKind,hasPatientGeometry:true,eye:'OD',visit:'latest',nx:n,ny:n,axisX:axis,axisY:[...axis],radius:r,vertices,triangles,displayMaps:{[field]:descriptor}};
 return {model,descriptor,center:((n-1)/2)*n+(n-1)/2,axis};
}
function remove(f,indices,status=0){for(const k of indices){f.descriptor.values[k]=null;f.descriptor.status[k]=status;f.descriptor.sampling[k]=null;f.descriptor.intervalWidths[k]=null;}}

test('A source footprint is retained beside a missing neighbor without inventing a missing point reading',()=>{
 const f=fixture();remove(f,[f.center]);const field=C.getField(C.prepare(f.model),'anterior',false);
 assert.equal(C.sample(field,0,0),null);
 const nearby=C.sample(field,.075,0);assert(nearby);assert.equal(nearby.method,'source-footprint');close(nearby.value,45.2);assert.equal(nearby.status,1);
 assert.equal(field.sourceStatus[f.center],0);assert.equal(field.values[f.center],null);
});
test('A small enclosed spatial holdout reconstructs an affine field and stays explicitly estimated',()=>{
 const f=fixture(),expected=f.descriptor.values[f.center];remove(f,[f.center]);const prepared=C.prepare(f.model),raw=C.getField(prepared,'anterior',false),filled=C.getField(prepared,'anterior',true);
 assert.equal(raw.status[f.center],0);assert.equal(filled.status[f.center],2);close(filled.values[f.center],expected);
 assert.equal(C.sample(filled,0,0).estimated,true);assert.equal(filled.coverage.estimated,1);assert.equal(raw.coverage.estimated,0);
 assert.deepEqual(raw.range,filled.range);assert.deepEqual(raw.sourceValues,filled.sourceValues);assert.deepEqual(raw.sourceStatus,filled.sourceStatus);
});
test('Connected blocks obey physical span and area limits across display resolutions',()=>{
 const small=fixture({n:41,r:3});remove(small,[small.center,small.center+1]);const accepted=C.getField(C.prepare(small.model),'anterior');
 assert.equal(accepted.coverage.estimated,2);
 const area=fixture({n:41,r:3});remove(area,[area.center,area.center+1,area.center+41,area.center+42]);
 assert.equal(C.getField(C.prepare(area.model),'anterior').coverage.estimated,0);
 const span=fixture({n:41,r:2});remove(span,[span.center,span.center+1,span.center+2,span.center+3]);
 assert.equal(C.getField(C.prepare(span.model),'anterior').coverage.estimated,0);
});
test('Clipped samples and adjacent gaps remain unavailable even with a smooth surrounding field',()=>{
 const f=fixture();remove(f,[f.center],3);remove(f,[f.center+1]);const field=C.getField(C.prepare(f.model),'anterior');
 assert.equal(field.status[f.center],3);assert.equal(field.status[f.center+1],0);assert.equal(field.coverage.estimated,0);assert.equal(field.coverage.clipped,1);
 assert.equal(C.sample(field,0,0),null);assert(field.diagnostics.some(d=>d.reason==='clipped-neighbor'));
});
test('Boundary-connected and unsupported-geometry holes are never completed',()=>{
 const edge=fixture();for(let i=20;i<41;i++)remove(edge,[20*41+i]);const a=C.getField(C.prepare(edge.model),'anterior');
 assert.equal(a.coverage.estimated,0);assert(a.diagnostics.some(d=>d.reason==='boundary'));
 const f=fixture();f.model.vertices[f.center]=null;f.model.triangles=f.model.triangles.filter(ids=>!ids.includes(f.center));remove(f,[f.center]);
 const b=C.getField(C.prepare(f.model),'anterior');assert.equal(b.status[f.center],0);assert.equal(b.eligible[f.center],0);assert.equal(b.coverage.estimated,0);assert(b.geometryUnavailable>0);
});
test('Native numerical missing values stay missing and native posterior magnitude is preserved',()=>{
 const f=fixture({sourceKind:'native',field:'posterior',fn:(x,y)=>-6-.1*x});delete f.model.displayMaps;f.model.vertices[f.center].posterior=null;
 const field=C.getField(C.prepare(f.model),'posterior');assert.equal(field.status[f.center],0);assert.equal(field.coverage.estimated,0);
 close(C.sample(field,.1,0).value,6.01);assert(field.range.min>=0);
});
test('Constant native fields retain exact values and an exactly constant range after axis reversal',()=>{
 const f=fixture({sourceKind:'native',field:'thickness',fn:()=>497,n:61,r:4.5});delete f.model.displayMaps;
 const reverseRows=[];for(let j=0;j<f.model.ny;j++)reverseRows.push(...f.model.vertices.slice(j*f.model.nx,(j+1)*f.model.nx).reverse());
 f.model.axisX.reverse();f.model.vertices=reverseRows;f.model.triangles=f.model.triangles.map(ids=>ids.map(k=>Math.floor(k/f.model.nx)*f.model.nx+(f.model.nx-1-k%f.model.nx)));
 const field=C.getField(C.prepare(f.model),'thickness');assert.equal(field.range.min,497);assert.equal(field.range.max,497);
 assert(field.values.every(value=>value===null||value===497));assert.equal(C.sample(field,.321,.123).value,497);
});
test('Already recovered colors cannot recursively become support for a new estimate',()=>{
 const f=fixture();f.descriptor.sampling=f.descriptor.sampling.map(v=>v?'local_color':null);remove(f,[f.center]);
 const field=C.getField(C.prepare(f.model),'anterior');assert.equal(field.status[f.center],0);assert.equal(field.coverage.estimated,0);
 const direct=fixture();remove(direct,[direct.center,direct.center+1]);const before=JSON.stringify(direct.descriptor),filled=C.getField(C.prepare(direct.model),'anterior');
 assert.equal(filled.coverage.estimated,2);assert.equal(JSON.stringify(direct.descriptor),before);assert.equal(filled.sourceStatus[direct.center],0);assert.equal(filled.sampling[direct.center],null);
});
test('A locally inconsistent field abstains rather than smoothing a hidden discontinuity',()=>{
 const f=fixture({fn:(x,y)=>45+15*Math.sin(x*40)*Math.cos(y*30),bin:.1});remove(f,[f.center]);
 const field=C.getField(C.prepare(f.model),'anterior');assert.equal(field.coverage.estimated,0);assert(field.diagnostics.some(d=>d.reason==='insufficient-local-fit'));
});
test('Fill values are bounded by surrounding source values and cannot alter mapped minima',()=>{
 const f=fixture({field:'thickness',fn:(x,y)=>430+12*x*x+7*y*y,bin:8}),beforeMin=M.findThinnest(f.model);
 remove(f,[f.center]);const snapshot=JSON.stringify(f.model);freeze(f.model);
 const field=C.getField(C.prepare(f.model),'thickness');assert.equal(field.status[f.center],2);
 assert(field.values[f.center]>=field.range.min&&field.values[f.center]<=field.range.max);
 assert.equal(JSON.stringify(f.model),snapshot);assert.deepEqual(M.findThinnest(f.model),beforeMin);assert.equal(field.sourceValues[f.center],null);
});
test('Signed elevation keeps its sign and contour gradients do not mark constant plateaus',()=>{
 const signed=fixture({field:'posterior_elevation',fn:(x,y)=>-20+3*x+2*y});remove(signed,[signed.center]);
 const grid=C.getField(C.prepare(signed.model),'posterior_elevation');close(C.sample(grid,0,0).value,-20);assert(grid.range.max<0);
 assert.equal(C.sample(grid,.025,.025).gradient,true);
 const flat=fixture({fn:()=>45}),plateau=C.getField(C.prepare(flat.model),'anterior');assert.equal(C.sample(plateau,.025,.025).gradient,false);
});
test('Image display descriptors preserve physical orientation, canonical curvature and clipped provenance',()=>{
 const grid=Array.from({length:41},(_,j)=>Array.from({length:41},(_,i)=>{const value=(i-20)*.15+10*(20-j)*.15;return {value,lo:value-.5,hi:value+.5,sampling:'direct'};}));
 const map={diameter_mm:9,extent:2/3,elevation_um:grid,legend_provenance:{anchors:[-100,0,100].map(value=>({value}))}};
 const d=A.displayDescriptor(map,'elevation','elevation_um');assert.equal(d.xMin,-3);assert.equal(d.yMin,-3);close(d.values[40*41+20],30);close(d.values[20],-30);
 const radiusMap={diameter_mm:9,extent:2/3,unit:'mm',grid:grid.map(row=>row.map(()=>({value:6,lo:5.9,hi:6.1,sampling:'direct'}))),legend:{anchors:[1,5,10].map(value=>({value}))}};
 const p=A.displayDescriptor(radiusMap,'posterior','grid');close(p.values[20*41+20],40/6);
 radiusMap.grid[20][20]={value:1.1,lo:1,hi:1.2,sampling:'direct'};const censored=A.displayDescriptor(radiusMap,'posterior','grid');assert.equal(censored.status[20*41+20],3);assert.equal(censored.values[20*41+20],null);
});
test('Coverage fractions use eligible retained geometry and count clipping as unavailable',()=>{
 const f=fixture();remove(f,[f.center]);remove(f,[f.center+8],3);const field=C.getField(C.prepare(f.model),'anterior');
 const c=field.coverage;assert.equal(c.total,c.source+c.estimated+c.unavailable);assert(c.clipped<=c.unavailable);close(c.sourcePercent+c.estimatedPercent+c.unavailablePercent,100);
 assert(field.status.every((s,k)=>field.eligible[k]||s===0));assert.equal(C.sample(field,3,0),null);assert.equal(C.sample(field,1.9,1.9),null);
});
console.log(`${count} integrated-coverage checks passed.`);
